package com.netflix.accessor.models;

public enum ShowGenre {
    Horror,
    Comedy,
    Action,
    DRAMA
}
