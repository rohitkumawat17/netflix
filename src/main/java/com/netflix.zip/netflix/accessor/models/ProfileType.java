package com.netflix.accessor.models;

public enum ProfileType {
    GENERAL,KIDS
}
