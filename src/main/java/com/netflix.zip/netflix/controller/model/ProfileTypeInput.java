package com.netflix.controller.model;

public enum ProfileTypeInput {
    GENERAL,
    KIDS
}
