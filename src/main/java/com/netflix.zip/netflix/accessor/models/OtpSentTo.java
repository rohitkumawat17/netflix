package com.netflix.accessor.models;

public enum OtpSentTo {
    EMAIL,
    PHONE
}
