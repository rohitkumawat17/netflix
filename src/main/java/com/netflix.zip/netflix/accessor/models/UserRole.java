package com.netflix.accessor.models;

public enum UserRole {
    ROLE_USER,
    ROLE_CUSTOMER
}
