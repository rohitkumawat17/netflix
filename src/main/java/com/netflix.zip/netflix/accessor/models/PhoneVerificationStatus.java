package com.netflix.accessor.models;

public enum PhoneVerificationStatus {
    UNVERIFIED,
    VERIFIED
}
