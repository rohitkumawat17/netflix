package com.netflix.accessor.models;

public enum OtpState {
    UNUSED,
    USED,
    EXPIRED
}
