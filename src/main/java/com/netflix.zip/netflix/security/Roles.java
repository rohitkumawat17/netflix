package com.netflix.security;

public class Roles {
    public final static String Customer = "ROLE_CUSTOMER";
    public final static String User = "ROLE_USER";
    public final static String Anonymous = "ROLE_ANONYMOUS";
}
