package com.netflix.accessor.models;

public enum EmailVerificationStatus {
    UNVERIFIED,
    VERIFIED
}
