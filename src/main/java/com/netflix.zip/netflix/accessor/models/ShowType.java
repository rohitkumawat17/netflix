package com.netflix.accessor.models;

public enum ShowType {
    MOVIE,
    TV_SHOW
}
