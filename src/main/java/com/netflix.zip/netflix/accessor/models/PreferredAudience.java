package com.netflix.accessor.models;

public enum PreferredAudience {
    Kids,
    Adult,
    General
}
