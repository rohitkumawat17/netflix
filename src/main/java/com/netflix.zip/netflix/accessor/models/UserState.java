package com.netflix.accessor.models;

public enum UserState {
    ACTIVE,
    DEACTIVATED,
    SUSPENDED
}
